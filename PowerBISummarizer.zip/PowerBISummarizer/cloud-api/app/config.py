from pathlib import Path

# Base directory where uploaded GPKG files will be stored.
UPLOAD_DIR = Path("/data/gpkg")
