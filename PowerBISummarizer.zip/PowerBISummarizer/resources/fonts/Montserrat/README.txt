
As fontes Montserrat não estão inclusas neste pacote.
Para obter a aparência idêntica em qualquer máquina, baixe os arquivos TTF no Google Fonts
(https://fonts.google.com/specimen/Montserrat) e coloque-os nesta pasta:

resources/fonts/Montserrat/
  - Montserrat-Regular.ttf
  - Montserrat-Medium.ttf
  - Montserrat-SemiBold.ttf

Se preferir, instale Montserrat no sistema operacional (será usado como fallback).
